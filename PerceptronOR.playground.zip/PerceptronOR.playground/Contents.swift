import UIKit
import Foundation

enum LogicalOperator {
    case or, and, xor, xnor
    
    func getDataSet() -> [DataSet] {
        switch self {
        case .or:
            return initializeDataSetForOR()
        case .and:
            return initializeDataSetForAND()
        case .xor:
            return initializeDataSetForXOR()
        case .xnor:
            return initializeDataSetForXNOR()
        }
    }
    
    func initializeDataSetForOR() -> [DataSet] {
        var dataSet = [DataSet]()
        dataSet.append(DataSet(inputs: [0,0], desiredOutput: 0))
        dataSet.append(DataSet(inputs: [0,1], desiredOutput: 1))
        dataSet.append(DataSet(inputs: [1,0], desiredOutput: 1))
        dataSet.append(DataSet(inputs: [1,1], desiredOutput: 1))
        return dataSet
    }
    
    func initializeDataSetForAND() -> [DataSet] {
        var dataSet = [DataSet]()
        dataSet.append(DataSet(inputs: [0,0], desiredOutput: 0))
        dataSet.append(DataSet(inputs: [0,1], desiredOutput: 0))
        dataSet.append(DataSet(inputs: [1,0], desiredOutput: 0))
        dataSet.append(DataSet(inputs: [1,1], desiredOutput: 1))
        return dataSet
    }
    
    func initializeDataSetForXOR() -> [DataSet] {
        var dataSet = [DataSet]()
        dataSet.append(DataSet(inputs: [0,0], desiredOutput: 0))
        dataSet.append(DataSet(inputs: [0,1], desiredOutput: 1))
        dataSet.append(DataSet(inputs: [1,0], desiredOutput: 1))
        dataSet.append(DataSet(inputs: [1,1], desiredOutput: 0))
        return dataSet
    }
    
    func initializeDataSetForXNOR() -> [DataSet] {
        var dataSet = [DataSet]()
        dataSet.append(DataSet(inputs: [0,0], desiredOutput: 1))
        dataSet.append(DataSet(inputs: [0,1], desiredOutput: 0))
        dataSet.append(DataSet(inputs: [1,0], desiredOutput: 0))
        dataSet.append(DataSet(inputs: [1,1], desiredOutput: 1))
        return dataSet
    }
}

struct DataSet {
    let inputs: [Double]
    let desiredOutput: Double
}

//MARK:- Initializers
class PerceptronOR {
    var dataSet: [DataSet] = []
    var weights: [Double] = []
    var bias: Double = 0
    var output: Double = 0
    var error: Double = 0
    var epoch: Int
    var logicalOperator: LogicalOperator
    
    
    init(epochValue: Int = 6, logicalOperator: LogicalOperator = .or) {
        epoch = epochValue
        self.logicalOperator = logicalOperator
        dataSet = logicalOperator.getDataSet()
        initializeWeights()
        initializeBias()
    }

    func initializeWeights() {
        weights = []
        for _ in 0 ..< 2 {
            weights.append(Double.random(in: -1 ... 1))
        }
    }
    
    func initializeBias() {
        bias = Double.random(in: -1 ... 1)
    }
}

//MARK:- Updates
extension PerceptronOR {
    func updateWeights(index: Int) {
        let dataset = dataSet[index]
        for i in 0 ..< dataset.inputs.count {
            weights[i] = dataset.inputs[i] * error + weights[i]
        }
    }
    
    func updateBias() {
        bias = bias + error
    }
    
    func updateError(index: Int) {
        let dataset = dataSet[index]
        error = dataset.desiredOutput - output
    }
}
//MARK:- Output
extension PerceptronOR {
    func calculateDotProductOutput(inputs: [Double]) -> Double {
        
        var tempOutput = 0.0
        for i in 0 ..< inputs.count {
            tempOutput += (inputs[i] * weights[i])
        }
        tempOutput += bias
        return tempOutput
    }
    
    func updateOutput(index: Int) {
        let dataset = dataSet[index]
        updateOutput(inputs: dataset.inputs)
    }
    
    func updateOutput(inputs: [Double]) {
        let calculatedOutput = calculateDotProductOutput(inputs:inputs)
        //print("calculatedOutput = \(calculatedOutput)")
        if calculatedOutput.sign == .plus { //output = calculatedOutput > 0 ? 1 : 0
            output = 1
        } else {
            output = 0
        }
    }
}

//MARK:- Traing
extension PerceptronOR {
    func trainModel() {
        for _ in 0 ..< epoch {
            for j in 0 ..< dataSet.count {
                updateOutput(index: j)
                updateError(index: j)
                updateWeights(index: j)
                updateBias()
                printIntermediateResult(index: j)
            }
            print("\n")
        }
    }
    
    func printIntermediateResult(index: Int) {
        let input1 = dataSet[index].inputs[0]
        let input2 = dataSet[index].inputs[1]
        let weight1 = weights[0]
        let weight2 = weights[1]
        print("Input1 = \(input1)   Input2 = \(input2)  Weight1 = \(weight1)  Weight2 = \(weight2)  Bias = \(bias)  Output = \(output)  DesiredOutput = \(dataSet[index].desiredOutput)    Error = \(error)")
    }
    
    func printResultFor(input1: Double, input2: Double) {
        updateOutput(inputs: [input1, input2])
        print("Input1 = \(input1)   Input2 = \(input2)  Output = \(output)")
    }
}

let perceptronClass = PerceptronOR(epochValue: 8)
perceptronClass.trainModel()
perceptronClass.printResultFor(input1: 0, input2: 0)
perceptronClass.printResultFor(input1: 0, input2: 1)
perceptronClass.printResultFor(input1: 1, input2: 0)
perceptronClass.printResultFor(input1: 1, input2: 1)

